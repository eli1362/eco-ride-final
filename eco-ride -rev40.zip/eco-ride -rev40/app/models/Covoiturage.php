<?php

namespace models;

class Covoiturage
{

}